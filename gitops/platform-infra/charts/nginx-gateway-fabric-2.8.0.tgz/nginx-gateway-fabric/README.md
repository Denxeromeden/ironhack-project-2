
# NGINX Gateway Fabric Helm Chart

![Version: 2.8.0](https://img.shields.io/badge/Version-2.8.0-informational?style=flat-square) ![AppVersion: 2.8.0](https://img.shields.io/badge/AppVersion-2.8.0-informational?style=flat-square)

- [NGINX Gateway Fabric Helm Chart](#nginx-gateway-fabric-helm-chart)
  - [Introduction](#introduction)
  - [Prerequisites](#prerequisites)
    - [Installing the Gateway API resources](#installing-the-gateway-api-resources)
  - [Requirements](#requirements)
  - [Installing the Chart](#installing-the-chart)
    - [Installing the Chart from the OCI Registry](#installing-the-chart-from-the-oci-registry)
    - [Installing the Chart via Sources](#installing-the-chart-via-sources)
      - [Pulling the Chart](#pulling-the-chart)
      - [Installing the Chart](#installing-the-chart-1)
    - [Custom installation options](#custom-installation-options)
      - [Service type](#service-type)
  - [Upgrading the Chart](#upgrading-the-chart)
    - [Upgrading the Gateway Resources](#upgrading-the-gateway-resources)
    - [Upgrading the CRDs](#upgrading-the-crds)
    - [Upgrading the Chart from the OCI Registry](#upgrading-the-chart-from-the-oci-registry)
    - [Upgrading the Chart from the Sources](#upgrading-the-chart-from-the-sources)
  - [Uninstalling the Chart](#uninstalling-the-chart)
    - [Uninstalling the Gateway Resources](#uninstalling-the-gateway-resources)
  - [Configuration](#configuration)

## Introduction

This chart deploys the NGINX Gateway Fabric in your Kubernetes cluster.

## Prerequisites

- [Helm 3.0+](https://helm.sh/docs/intro/install/)
- [kubectl](https://kubernetes.io/docs/tasks/tools/)

### Installing the Gateway API resources

> [!NOTE]
>
> The [Gateway API resources](https://github.com/kubernetes-sigs/gateway-api) from the standard channel must be
> installed before deploying NGINX Gateway Fabric. If they are already installed in your cluster, please ensure
> they are the correct version as supported by the NGINX Gateway Fabric -
> [see the Technical Specifications](https://github.com/nginx/nginx-gateway-fabric/blob/main/README.md#technical-specifications).

```shell
kubectl kustomize https://github.com/nginx/nginx-gateway-fabric/config/crd/gateway-api/standard | kubectl apply -f -
```

## Requirements

Kubernetes: `>= 1.32.0-0`

## Installing the Chart

### Installing the Chart from the OCI Registry

To install the latest stable release of NGINX Gateway Fabric in the `nginx-gateway` namespace, run the following command:

```shell
helm install ngf oci://ghcr.io/nginx/charts/nginx-gateway-fabric --create-namespace -n nginx-gateway
```

`ngf` is the name of the release, and can be changed to any name you want. This name is added as a prefix to the Deployment name.

If the namespace already exists, you can omit the optional `--create-namespace` flag. If you want the latest version from the `main` branch, add `--version 0.0.0-edge` to your install command.

To wait for the Deployment to be ready, you can either add the `--wait` flag to the `helm install` command, or run
the following after installing:

```shell
kubectl wait --timeout=5m -n nginx-gateway deployment/ngf-nginx-gateway-fabric --for=condition=Available
```

### Installing the Chart via Sources

#### Pulling the Chart

```shell
helm pull oci://ghcr.io/nginx/charts/nginx-gateway-fabric --untar
cd nginx-gateway-fabric
```

This will pull the latest stable release. To pull the latest version from the `main` branch, specify the
`--version 0.0.0-edge` flag when pulling.

#### Installing the Chart

To install the chart into the `nginx-gateway` namespace, run the following command.

```shell
helm install ngf . --create-namespace -n nginx-gateway
```

`ngf` is the name of the release, and can be changed to any name you want. This name is added as a prefix to the Deployment name.

If the namespace already exists, you can omit the optional `--create-namespace` flag.

To wait for the Deployment to be ready, you can either add the `--wait` flag to the `helm install` command, or run
the following after installing:

```shell
kubectl wait --timeout=5m -n nginx-gateway deployment/ngf-nginx-gateway-fabric --for=condition=Available
```

### Custom installation options

#### Service type

By default, the NGINX Gateway Fabric helm chart deploys a LoadBalancer Service.

To use a NodePort Service instead:

```shell
helm install ngf oci://ghcr.io/nginx/charts/nginx-gateway-fabric --create-namespace -n nginx-gateway --set nginx.service.type=NodePort
```

## Upgrading the Chart

### Upgrading the Gateway Resources

Before you upgrade a release, ensure the Gateway API resources are the correct version as supported by the NGINX
Gateway Fabric - [see the Technical Specifications](https://github.com/nginx/nginx-gateway-fabric/blob/main/README.md#technical-specifications).:

To upgrade the Gateway CRDs from [the Gateway API repo](https://github.com/kubernetes-sigs/gateway-api), run:

```shell
kubectl kustomize https://github.com/nginx/nginx-gateway-fabric/config/crd/gateway-api/standard | kubectl apply -f -
```

### Upgrading the CRDs

Helm does not upgrade the NGINX Gateway Fabric CRDs during a release upgrade. Before you upgrade a release, you
must [pull the chart](#pulling-the-chart) from GitHub and run the following command to upgrade the CRDs:

```shell
kubectl apply --server-side -f crds/
```

The following warning is expected and can be ignored:

```text
Warning: kubectl apply should be used on resource created by either kubectl create --save-config or kubectl apply.
```

### Upgrading the Chart from the OCI Registry

To upgrade the release `ngf`, run:

```shell
helm upgrade ngf oci://ghcr.io/nginx/charts/nginx-gateway-fabric -n nginx-gateway
```

This will upgrade to the latest stable release. To upgrade to the latest version from the `main` branch, specify
the `--version 0.0.0-edge` flag when upgrading.

### Upgrading the Chart from the Sources

Pull the chart sources as described in [Pulling the Chart](#pulling-the-chart), if not already present. Then, to upgrade
the release `ngf`, run:

```shell
helm upgrade ngf . -n nginx-gateway
```

## Uninstalling the Chart

To uninstall/delete the release `ngf`:

```shell
helm uninstall ngf -n nginx-gateway
kubectl delete ns nginx-gateway
kubectl delete -f https://raw.githubusercontent.com/nginx/nginx-gateway-fabric/main/deploy/crds.yaml
```

These commands remove all the Kubernetes components associated with the release and deletes the release.

### Uninstalling the Gateway Resources

> **Warning: This command will delete all the corresponding custom resources in your cluster across all namespaces!
> Please ensure there are no custom resources that you want to keep and there are no other Gateway API implementations
> running in the cluster!**

To delete the Gateway API CRDs from [the Gateway API repo](https://github.com/kubernetes-sigs/gateway-api), run:

```shell
kubectl kustomize https://github.com/nginx/nginx-gateway-fabric/config/crd/gateway-api/standard | kubectl delete -f -
```

## Configuration

The following table lists the configurable parameters of the NGINX Gateway Fabric chart and their default values.

> More granular configuration options may not show up in this table.
> Viewing the `values.yaml` file directly can show all available options.

| Key | Description | Type | Default |
|-----|-------------|------|---------|
| `certGenerator` | The certGenerator section contains the configuration for the cert-generator Job. | object | `{"affinity":{},"agentTLSSecretName":"agent-tls","annotations":{},"automountServiceAccountToken":true,"enable":true,"extraVolumeMounts":[],"extraVolumes":[],"nodeSelector":{},"overwrite":false,"serverTLSSecretName":"server-tls","tolerations":[],"topologySpreadConstraints":[],"ttlSecondsAfterFinished":30}` |
| `certGenerator.affinity` | The affinity of the cert-generator pod. | object | `{}` |
| `certGenerator.agentTLSSecretName` | The name of the base Secret containing TLS CA, certificate, and key for the NGINX Agent to securely communicate with the NGINX Gateway Fabric control plane. Must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `"agent-tls"` |
| `certGenerator.annotations` | The annotations of the cert-generator Job. | object | `{}` |
| `certGenerator.automountServiceAccountToken` | automountServiceAccountToken controls whether the Kubernetes service account token is automatically mounted into the cert-generator pod. Set to false to disable automatic token mounting. When disabled, use certGenerator.extraVolumes to mount a projected token if required. | bool | `true` |
| `certGenerator.enable` | Enable the cert-generator Job. If this is disabled, then cert-manager or some other method must be used to create the required Secrets. | bool | `true` |
| `certGenerator.extraVolumeMounts` | extraVolumeMounts are the additional volume mounts for the cert-generator container. | list | `[]` |
| `certGenerator.extraVolumes` | extraVolumes for the cert-generator pod. Use in conjunction with certGenerator.extraVolumeMounts to mount additional volumes into the container (e.g. a projected service account token). | list | `[]` |
| `certGenerator.nodeSelector` | The nodeSelector of the cert-generator pod. | object | `{}` |
| `certGenerator.overwrite` | Overwrite existing TLS Secrets on startup. | bool | `false` |
| `certGenerator.serverTLSSecretName` | The name of the Secret containing TLS CA, certificate, and key for the NGINX Gateway Fabric control plane to securely communicate with the NGINX Agent. Must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `"server-tls"` |
| `certGenerator.tolerations` | Tolerations for the cert-generator pod. | list | `[]` |
| `certGenerator.topologySpreadConstraints` | The topology spread constraints for the cert-generator pod. | list | `[]` |
| `certGenerator.ttlSecondsAfterFinished` | How long to wait after the cert generator job has finished before it is removed by the job controller. | int | `30` |
| `clusterDomain` | The DNS cluster domain of your Kubernetes cluster. | string | `"cluster.local"` |
| `extraObjects` | A list of extra Kubernetes manifests to deploy. Each item is a raw YAML string representing a complete Kubernetes resource. Useful for deploying additional resources (e.g. ConfigMaps, Secrets, NetworkPolicies) alongside the chart without creating a separate chart. | list | `[]` |
| `fullnameOverride` | String to fully override the generated resource names. | string | `""` |
| `gateways` | A list of Gateway objects. View https://gateway-api.sigs.k8s.io/reference/spec/#gateway for full Gateway reference. | list | `[]` |
| `nameOverride` | String to partially override the chart name used for resource naming. | string | `""` |
| `nginx` | The nginx section contains the configuration for all NGINX data plane deployments installed by the NGINX Gateway Fabric control plane. | object | `{"autoscaling":{"annotations":{},"behavior":{},"enable":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":50,"targetMemoryUtilizationPercentage":50},"config":{},"container":{"hostPorts":[],"lifecycle":{},"readinessProbe":{},"resources":{},"volumeMounts":[]},"debug":false,"image":{"pullPolicy":"IfNotPresent","repository":"ghcr.io/nginx/nginx-gateway-fabric/nginx","tag":"2.8.0"},"imagePullSecret":"","imagePullSecrets":[],"kind":"deployment","nginxInstanceManager":{"endpointHost":"","endpointPort":4317},"nginxOneConsole":{"dataplaneKeySecretName":"","endpointHost":"agent.connect.nginx.com","endpointPort":443,"skipVerify":false},"patches":[],"plus":false,"pod":{},"podDisruptionBudget":{"enable":false,"maxUnavailable":"","minAvailable":1,"unhealthyPodEvictionPolicy":""},"replicas":1,"service":{"externalTrafficPolicy":"Local","loadBalancerClass":"","loadBalancerIP":"","loadBalancerSourceRanges":[],"nodePorts":[],"patches":[],"type":"LoadBalancer"},"serviceMonitor":{"enable":false,"interval":"","port":"metrics"},"usage":{"caSecretName":"","clientSSLSecretName":"","endpoint":"","enforceInitialReport":true,"resolver":"","secretName":"nplus-license","skipVerify":false},"wafContainers":{}}` |
| `nginx.autoscaling` | Autoscaling configuration for the NGINX data plane. | object | `{"annotations":{},"behavior":{},"enable":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":50,"targetMemoryUtilizationPercentage":50}` |
| `nginx.autoscaling.annotations` | Set of custom annotations for the HPA object. | object | `{}` |
| `nginx.autoscaling.behavior` | The full HPA `spec.behavior` object, passed as-is to the HPA resource. Accepts any valid Kubernetes HPA behavior spec. See the [Kubernetes docs](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#configurable-scaling-behavior) for all available fields. | object | `{}` |
| `nginx.autoscaling.enable` | Enable or disable Horizontal Pod Autoscaler for the NGINX data plane. | bool | `false` |
| `nginx.autoscaling.maxReplicas` | Maximum number of replicas for the NGINX data plane HPA. | int | `10` |
| `nginx.autoscaling.metrics` | Custom or additional autoscaling metrics. https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#scaling-on-custom-metrics | list | `[]` |
| `nginx.autoscaling.minReplicas` | Minimum number of replicas for the NGINX data plane HPA. | int | `1` |
| `nginx.autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage for the NGINX data plane HPA. Requires `nginx.container.resources` to be set. | int | `50` |
| `nginx.autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage for the NGINX data plane HPA. Requires `nginx.container.resources` to be set. | | int | `50` |
| `nginx.config` | The configuration for the data plane that is contained in the NginxProxy resource. This is applied globally to all Gateways managed by this instance of NGINX Gateway Fabric. | object | `{}` |
| `nginx.container` | The container configuration for the NGINX container. This is applied globally to all Gateways managed by this instance of NGINX Gateway Fabric. | object | `{"hostPorts":[],"lifecycle":{},"readinessProbe":{},"resources":{},"volumeMounts":[]}` |
| `nginx.container.hostPorts` | A list of HostPorts to expose on the host. This configuration allows containers to bind to a specific port on the host node, enabling external network traffic to reach the container directly through the host's IP address and port. Use this option when you need to expose container ports on the host for direct access, such as for debugging, legacy integrations, or when NodePort/LoadBalancer services are not suitable. Note: Using hostPort may have security and scheduling implications, as it ties pods to specific nodes and ports. | list | `[]` |
| `nginx.container.lifecycle` | The lifecycle of the NGINX container. | object | `{}` |
| `nginx.container.resources` | The resource requirements of the NGINX container. You should set this value if you want to use dataplane Autoscaling(HPA). | object | `{}` |
| `nginx.container.volumeMounts` | volumeMounts are the additional volume mounts for the NGINX container. | list | `[]` |
| `nginx.debug` | Enable debugging for NGINX. Uses the nginx-debug binary. The NGINX error log level should be set to debug in the NginxProxy resource. | bool | `false` |
| `nginx.image.repository` | The NGINX image to use. | string | `"ghcr.io/nginx/nginx-gateway-fabric/nginx"` |
| `nginx.imagePullSecret` | The name of the secret containing docker registry credentials. Secret must exist in the same namespace as the helm release. The control plane will copy this secret into any namespace where NGINX is deployed. | string | `""` |
| `nginx.imagePullSecrets` | A list of secret names containing docker registry credentials. Secrets must exist in the same namespace as the helm release. The control plane will copy these secrets into any namespace where NGINX is deployed. | list | `[]` |
| `nginx.kind` | The kind of NGINX deployment. | string | `"deployment"` |
| `nginx.nginxInstanceManager` | Configuration for NGINX Instance Manager. | object | `{"endpointHost":"","endpointPort":4317}` |
| `nginx.nginxInstanceManager.endpointHost` | The Endpoint host that the NGINX Instance Manager telemetry data will be sent to. | string | `""` |
| `nginx.nginxInstanceManager.endpointPort` | The endpoint port that the NGINX Instance Manager telemetry data will be sent to. | int | `4317` |
| `nginx.nginxOneConsole` | Configuration for NGINX One Console. | object | `{"dataplaneKeySecretName":"","endpointHost":"agent.connect.nginx.com","endpointPort":443,"skipVerify":false}` |
| `nginx.nginxOneConsole.dataplaneKeySecretName` | Name of the secret which holds the dataplane key that is required to authenticate with the NGINX One Console. Secret must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `""` |
| `nginx.nginxOneConsole.endpointHost` | The Endpoint host that the NGINX One Console telemetry metrics will be sent to. | string | `"agent.connect.nginx.com"` |
| `nginx.nginxOneConsole.endpointPort` | The endpoint port that the NGINX One Console telemetry metrics will be sent to. | int | `443` |
| `nginx.nginxOneConsole.skipVerify` | Skip TLS verification for NGINX One Console connections. | bool | `false` |
| `nginx.patches` | Custom patches to apply to the NGINX Deployment/DaemonSet. | list | `[]` |
| `nginx.plus` | Is NGINX Plus image being used. | bool | `false` |
| `nginx.pod` | The pod configuration for the NGINX data plane pod. This is applied globally to all Gateways managed by this instance of NGINX Gateway Fabric. | object | `{}` |
| `nginx.podDisruptionBudget` | PodDisruptionBudget configuration for the NGINX data plane. Only applies when `nginx.kind` is `deployment`. A PodDisruptionBudget is created for every NGINX Deployment provisioned for a Gateway that uses this NginxProxy. | object | `{"enable":false,"maxUnavailable":"","minAvailable":1,"unhealthyPodEvictionPolicy":""}` |
| `nginx.podDisruptionBudget.enable` | Enable or disable PodDisruptionBudget for the NGINX data plane. | bool | `false` |
| `nginx.podDisruptionBudget.maxUnavailable` | Maximum number of pods that can be unavailable after an eviction. Value can be an absolute number (e.g. 1) or a percentage (e.g. 50%). Mutually exclusive with minAvailable. | string | `""` |
| `nginx.podDisruptionBudget.minAvailable` | Minimum number of pods that must be available after an eviction. Value can be an absolute number (e.g. 1) or a percentage (e.g. 50%). Mutually exclusive with maxUnavailable; set this to "" to use maxUnavailable instead. | int | `1` |
| `nginx.podDisruptionBudget.unhealthyPodEvictionPolicy` | Defines when unhealthy pods should be considered for eviction. Valid values are IfHealthyBudget and AlwaysAllow. | string | `""` |
| `nginx.replicas` | The number of replicas of the NGINX Deployment. This value is ignored if autoscaling.enable is true. | int | `1` |
| `nginx.service` | The service configuration for the NGINX data plane. This is applied globally to all Gateways managed by this instance of NGINX Gateway Fabric. | object | `{"externalTrafficPolicy":"Local","loadBalancerClass":"","loadBalancerIP":"","loadBalancerSourceRanges":[],"nodePorts":[],"patches":[],"type":"LoadBalancer"}` |
| `nginx.service.externalTrafficPolicy` | The externalTrafficPolicy of the service. The value Local preserves the client source IP. | string | `"Local"` |
| `nginx.service.loadBalancerClass` | LoadBalancerClass is the class of the load balancer implementation this Service belongs to. Requires nginx.service.type set to LoadBalancer. | string | `""` |
| `nginx.service.loadBalancerIP` | The static IP address for the load balancer. Requires nginx.service.type set to LoadBalancer. | string | `""` |
| `nginx.service.loadBalancerSourceRanges` | The IP ranges (CIDR) that are allowed to access the load balancer. Requires nginx.service.type set to LoadBalancer. | list | `[]` |
| `nginx.service.nodePorts` | A list of NodePorts to expose on the NGINX data plane service. Each NodePort MUST map to a Gateway listener port, otherwise it will be ignored. The default NodePort range enforced by Kubernetes is 30000-32767. | list | `[]` |
| `nginx.service.patches` | Custom patches to apply to the NGINX Service. | list | `[]` |
| `nginx.service.type` | The type of service to create for the NGINX data plane. | string | `"LoadBalancer"` |
| `nginx.serviceMonitor` | Defines the configuration of the serviceMonitor for the nginx data plane. | object | `{"enable":false,"interval":"","port":"metrics"}` |
| `nginx.serviceMonitor.enable` | Enable the serviceMonitor for the data plane. | bool | `false` |
| `nginx.serviceMonitor.interval` | The scraping interval used by the serviceMonitor when scraping metrics. | string | `""` |
| `nginx.serviceMonitor.port` | The name of the port used for scraping metrics. | string | `"metrics"` |
| `nginx.usage.caSecretName` | The name of the Secret containing the NGINX Instance Manager CA certificate. Must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `""` |
| `nginx.usage.clientSSLSecretName` | The name of the Secret containing the client certificate and key for authenticating with NGINX Instance Manager. Must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `""` |
| `nginx.usage.endpoint` | The endpoint of the NGINX Plus usage reporting server. Default: product.connect.nginx.com | string | `""` |
| `nginx.usage.enforceInitialReport` | Enable enforcement of the initial NGINX Plus licensing report. If set to false, the initial report is not enforced. | bool | `true` |
| `nginx.usage.resolver` | The nameserver used to resolve the NGINX Plus usage reporting endpoint. Used with NGINX Instance Manager. | string | `""` |
| `nginx.usage.secretName` | The name of the Secret containing the JWT for NGINX Plus usage reporting. Must exist in the same namespace that the NGINX Gateway Fabric control plane is running in (default namespace: nginx-gateway). | string | `"nplus-license"` |
| `nginx.usage.skipVerify` | Disable client verification of the NGINX Plus usage reporting server certificate. | bool | `false` |
| `nginx.wafContainers` | Configuration for NGINX App Protect WAF v5 containers. These containers are only deployed when WAF is enabled via nginx.config.waf.enable: true. All settings are optional overrides - defaults are provided by NGF. | object | `{}` |
| `nginxGateway` | The nginxGateway section contains configuration for the NGINX Gateway Fabric control plane deployment. | object | `{"affinity":{},"autoscaling":{"annotations":{},"behavior":{},"enable":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":50,"targetMemoryUtilizationPercentage":50},"config":{"logging":{"level":"info"}},"configAnnotations":{},"externalLoadBalancer":{"enable":false},"extraVolumeMounts":[],"extraVolumes":[],"gatewayClassAnnotations":{},"gatewayClassName":"nginx","gatewayControllerName":"gateway.nginx.org/nginx-gateway-controller","gwAPIExperimentalFeatures":{"enable":false},"gwAPIInferenceExtension":{"enable":false,"endpointPicker":{"disableTLS":false,"skipVerify":false}},"image":{"pullPolicy":"IfNotPresent","repository":"ghcr.io/nginx/nginx-gateway-fabric","tag":"2.8.0"},"kind":"deployment","labels":{},"leaderElection":{"enable":true,"leaseDuration":"","lockName":"","renewDeadline":"","retryPeriod":""},"lifecycle":{},"metrics":{"enable":true,"port":9113,"secure":false,"serviceMonitor":{"annotations":{},"enable":false,"interval":"","labels":{},"tlsConfig":{}}},"name":"","nodeSelector":{},"payloadProcessor":{"enable":false},"plmStorage":{"credentialsSecretName":"","tls":{"caSecretName":"","clientSSLSecretName":"","insecureSkipVerify":false},"url":""},"podAnnotations":{},"podDisruptionBudget":{"enable":false,"maxUnavailable":"","minAvailable":"","unhealthyPodEvictionPolicy":""},"priorityClassName":"","productTelemetry":{"enable":true},"readinessProbe":{"enable":true,"failureThreshold":3,"initialDelaySeconds":3,"periodSeconds":10,"port":8081,"successThreshold":1,"timeoutSeconds":1},"replicas":1,"resources":{},"service":{"annotations":{},"labels":{}},"serviceAccount":{"annotations":{},"automountServiceAccountToken":true,"imagePullSecret":"","imagePullSecrets":[],"name":""},"snippets":{"enable":false},"snippetsFilters":{"enable":false},"terminationGracePeriodSeconds":30,"tolerations":[],"topologySpreadConstraints":[],"watchNamespaces":[]}` |
| `nginxGateway.affinity` | The affinity of the NGINX Gateway Fabric control plane pod. | object | `{}` |
| `nginxGateway.autoscaling` | Autoscaling configuration for the NGINX Gateway Fabric control plane. | object | `{"annotations":{},"behavior":{},"enable":false,"maxReplicas":10,"metrics":[],"minReplicas":1,"targetCPUUtilizationPercentage":50,"targetMemoryUtilizationPercentage":50}` |
| `nginxGateway.autoscaling.annotations` | Set of custom annotations for the HPA object. | object | `{}` |
| `nginxGateway.autoscaling.behavior` | The full HPA `spec.behavior` object, passed as-is to the HPA resource. Accepts any valid Kubernetes HPA behavior spec. See the [Kubernetes docs](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#configurable-scaling-behavior) for all available fields. | object | `{}` |
| `nginxGateway.autoscaling.enable` | Enable or disable Horizontal Pod Autoscaler for the control plane. | bool | `false` |
| `nginxGateway.autoscaling.maxReplicas` | Maximum number of replicas for the NGINX data plane HPA. | int | `10` |
| `nginxGateway.autoscaling.metrics` | Custom or additional autoscaling metrics. https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#scaling-on-custom-metrics | list | `[]` |
| `nginxGateway.autoscaling.minReplicas` | Minimum number of replicas for the NGINX data plane HPA. | int | `1` |
| `nginxGateway.autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage for the NGINX data plane HPA. Requires `nginx.container.resources` to be set. | int | `50` |
| `nginxGateway.autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization percentage for the NGINX data plane HPA. Requires `nginx.container.resources` to be set. | | int | `50` |
| `nginxGateway.config.logging.level` | Log level. | string | `"info"` |
| `nginxGateway.configAnnotations` | Set of custom annotations for NginxGateway objects. | object | `{}` |
| `nginxGateway.externalLoadBalancer.enable` | Enable ExternalLoadBalancer support. Allows for fronting a Gateway with an external load balancer. Supported load balancers: - F5 BIG-IP, through F5 Container Ingress Services. | bool | `false` |
| `nginxGateway.extraVolumeMounts` | extraVolumeMounts are the additional volume mounts for the nginx-gateway container. | list | `[]` |
| `nginxGateway.extraVolumes` | extraVolumes for the NGINX Gateway Fabric control plane pod. Use in conjunction with nginxGateway.extraVolumeMounts mount additional volumes to the container. | list | `[]` |
| `nginxGateway.gatewayClassAnnotations` | Set of custom annotations for GatewayClass objects. | object | `{}` |
| `nginxGateway.gatewayClassName` | The name of the GatewayClass that will be created as part of this release. Every NGINX Gateway Fabric must have a unique corresponding GatewayClass resource. NGINX Gateway Fabric only processes resources that belong to its class - i.e. have the "gatewayClassName" field resource equal to the class. | string | `"nginx"` |
| `nginxGateway.gatewayControllerName` | The name of the Gateway controller. The controller name must be of the form: DOMAIN/PATH. The controller's domain is gateway.nginx.org. | string | `"gateway.nginx.org/nginx-gateway-controller"` |
| `nginxGateway.gwAPIExperimentalFeatures.enable` | Enable the experimental features of Gateway API which are supported by NGINX Gateway Fabric. Requires the Gateway APIs installed from the experimental channel. | bool | `false` |
| `nginxGateway.gwAPIInferenceExtension.enable` | Enable Gateway API Inference Extension support. Allows for configuring InferencePools to route traffic to AI workloads. | bool | `false` |
| `nginxGateway.gwAPIInferenceExtension.endpointPicker` | EndpointPicker TLS configuration. | object | `{"disableTLS":false,"skipVerify":false}` |
| `nginxGateway.gwAPIInferenceExtension.endpointPicker.disableTLS` | Disable TLS for EndpointPicker communication. By default, TLS is enabled. Set to true only for development/testing or when using a service mesh for encryption. | bool | `false` |
| `nginxGateway.gwAPIInferenceExtension.endpointPicker.skipVerify` | Disables TLS certificate verification when connecting to the EndpointPicker. If a BackendTLSPolicy is not defined and TLS is enabled, certificate verification is disabled. | bool | `false` |
| `nginxGateway.image` | The image configuration for the NGINX Gateway Fabric control plane. | object | `{"pullPolicy":"IfNotPresent","repository":"ghcr.io/nginx/nginx-gateway-fabric","tag":"2.8.0"}` |
| `nginxGateway.image.repository` | The NGINX Gateway Fabric image to use | string | `"ghcr.io/nginx/nginx-gateway-fabric"` |
| `nginxGateway.kind` | The kind of the NGINX Gateway Fabric installation - currently, only deployment is supported. | string | `"deployment"` |
| `nginxGateway.labels` | Set of labels to be added for NGINX Gateway Fabric deployment. | object | `{}` |
| `nginxGateway.leaderElection.enable` | Enable leader election. Leader election is used to avoid multiple replicas of the NGINX Gateway Fabric reporting the status of the Gateway API resources. If not enabled, all replicas of NGINX Gateway Fabric will update the statuses of the Gateway API resources. | bool | `true` |
| `nginxGateway.leaderElection.leaseDuration` | The duration that non-leader candidates will wait to force acquire leadership. Must be greater than renewDeadline. Must be parsable by https://pkg.go.dev/time#ParseDuration. | string | Defaults to controller-runtime's built-in default (15s) if not set or set to "". |
| `nginxGateway.leaderElection.lockName` | The name of the leader election lock. A Lease object with this name will be created in the same Namespace as the controller. | string | Autogenerated if not set or set to "". |
| `nginxGateway.leaderElection.renewDeadline` | The duration that the acting leader will retry refreshing leadership before giving up. Must be greater than retryPeriod * 1.2 and less than leaseDuration. Increase this value if leader election is failing due to slow Kubernetes API server responses. Must be parsable by https://pkg.go.dev/time#ParseDuration. | string | Defaults to controller-runtime's built-in default (10s) if not set or set to "". |
| `nginxGateway.leaderElection.retryPeriod` | The duration the leader election clients should wait between action tries. Must be less than renewDeadline. Must be parsable by https://pkg.go.dev/time#ParseDuration. | string | Defaults to controller-runtime's built-in default (2s) if not set or set to "". |
| `nginxGateway.lifecycle` | The lifecycle of the nginx-gateway container. | object | `{}` |
| `nginxGateway.metrics.enable` | Enable exposing metrics in the Prometheus format. | bool | `true` |
| `nginxGateway.metrics.port` | Set the port where the Prometheus metrics are exposed. | int | `9113` |
| `nginxGateway.metrics.secure` | Enable serving metrics via https. By default metrics are served via http. Please note that this endpoint will be secured with a self-signed certificate. | bool | `false` |
| `nginxGateway.metrics.serviceMonitor` | Defines the configuration of the serviceMonitor for the nginxGateway control plane. | object | `{"annotations":{},"enable":false,"interval":"","labels":{},"tlsConfig":{}}` |
| `nginxGateway.metrics.serviceMonitor.annotations` | Set the annotations to be added to the serviceMonitor. | object | `{}` |
| `nginxGateway.metrics.serviceMonitor.enable` | Enable the serviceMonitor for the control plane. | bool | `false` |
| `nginxGateway.metrics.serviceMonitor.interval` | The scraping interval used by the serviceMonitor when scraping metrics. | string | `""` |
| `nginxGateway.metrics.serviceMonitor.labels` | Set the labels to be added to the serviceMonitor. | object | `{}` |
| `nginxGateway.metrics.serviceMonitor.tlsConfig` | tlsConfig is an object that defines the full TLS configuration of the NGINX Gateway Fabric control plane for the Prometheus service monitor. All fields are optional and can be configured by the user. For the full information on the fields that can be used in this object, refer to the official Prometheus documentation: https://prometheus-operator.dev/docs/api-reference/api/#monitoring.coreos.com/v1.TLSConfig | object | `{}` |
| `nginxGateway.name` | The name of the NGINX Gateway Fabric deployment - if not present, then by default uses release name given during installation. | string | `""` |
| `nginxGateway.nodeSelector` | The nodeSelector of the NGINX Gateway Fabric control plane pod. | object | `{}` |
| `nginxGateway.payloadProcessor.enable` | Enable the PayloadProcessor API. PayloadProcessors enable declarative, ordered processing of HTTP request and response payloads by attaching to a Gateway or HTTPRoute, and are used to implement features such as Guardrails for AI workloads. | bool | `false` |
| `nginxGateway.plmStorage.credentialsSecretName` | The name of the Secret containing S3 credentials for PLM storage. Use "namespace/name" format for cross-namespace references, or plain "name" for the controller namespace. | string | `""` |
| `nginxGateway.plmStorage.tls.caSecretName` | The name of the Secret containing the CA certificate for PLM storage TLS verification. Use "namespace/name" format for cross-namespace references. | string | `""` |
| `nginxGateway.plmStorage.tls.clientSSLSecretName` | The name of the Secret containing client TLS certificate and key for mutual TLS with PLM storage. Use "namespace/name" format for cross-namespace references. | string | `""` |
| `nginxGateway.plmStorage.tls.insecureSkipVerify` | Disable TLS certificate verification for PLM storage connections (dev/test only). | bool | `false` |
| `nginxGateway.plmStorage.url` | The URL of the PLM S3-compatible storage endpoint (SeaweedFS filer S3 gateway). Example: https://my-release-f5-waf-seaweed-filer.plm-namespace.svc.cluster.local:9333 | string | `""` |
| `nginxGateway.podAnnotations` | Set of custom annotations for the NGINX Gateway Fabric pods. | object | `{}` |
| `nginxGateway.podDisruptionBudget` | PodDisruptionBudget configuration for the NGINX Gateway Fabric control plane. | object | `{"enable":false,"maxUnavailable":"","minAvailable":"","unhealthyPodEvictionPolicy":""}` |
| `nginxGateway.podDisruptionBudget.enable` | Enable or disable PodDisruptionBudget for the control plane. | bool | `false` |
| `nginxGateway.podDisruptionBudget.maxUnavailable` | Maximum number of pods that can be unavailable after an eviction. Value can be an absolute number (e.g. 1) or a percentage (e.g. 50%). Mutually exclusive with minAvailable. | string | `""` |
| `nginxGateway.podDisruptionBudget.minAvailable` | Minimum number of pods that must be available after an eviction. Value can be an absolute number (e.g. 1) or a percentage (e.g. 50%). Mutually exclusive with maxUnavailable. | string | `""` |
| `nginxGateway.podDisruptionBudget.unhealthyPodEvictionPolicy` | Defines when unhealthy pods should be considered for eviction. Valid values are IfHealthyBudget and AlwaysAllow. | string | `""` |
| `nginxGateway.priorityClassName` | The priority class name for the NGINX Gateway Fabric control plane pod. | string | `""` |
| `nginxGateway.productTelemetry.enable` | Enable the collection of product telemetry. | bool | `true` |
| `nginxGateway.readinessProbe.enable` | Enable the /readyz endpoint on the control plane. | bool | `true` |
| `nginxGateway.readinessProbe.failureThreshold` | The number of retries after a failed probe before marking the container as Unready. | int | `3` |
| `nginxGateway.readinessProbe.initialDelaySeconds` | The number of seconds after the Pod has started before the readiness probes are initiated. | int | `3` |
| `nginxGateway.readinessProbe.periodSeconds` | How often (in seconds) to perform the readiness probe. | int | `10` |
| `nginxGateway.readinessProbe.port` | Port in which the readiness endpoint is exposed. | int | `8081` |
| `nginxGateway.readinessProbe.successThreshold` | Minimum consecutive successes for the probe to be considered successful after having failed. | int | `1` |
| `nginxGateway.readinessProbe.timeoutSeconds` | Number of seconds after which the probe times out. | int | `1` |
| `nginxGateway.replicas` | The number of replicas of the NGINX Gateway Fabric Deployment. This value is ignored if autoscaling.enable is true. | int | `1` |
| `nginxGateway.resources` | The resource requests and/or limits of the nginx-gateway container. | object | `{}` |
| `nginxGateway.service` | The service configuration for the NGINX Gateway Fabric control plane. | object | `{"annotations":{},"labels":{}}` |
| `nginxGateway.service.annotations` | The annotations of the NGINX Gateway Fabric control plane service. | object | `{}` |
| `nginxGateway.service.labels` | The labels of the NGINX Gateway Fabric control plane service. | object | `{}` |
| `nginxGateway.serviceAccount` | The serviceaccount configuration for the NGINX Gateway Fabric control plane. | object | `{"annotations":{},"automountServiceAccountToken":true,"imagePullSecret":"","imagePullSecrets":[],"name":""}` |
| `nginxGateway.serviceAccount.annotations` | Set of custom annotations for the NGINX Gateway Fabric control plane service account. | object | `{}` |
| `nginxGateway.serviceAccount.automountServiceAccountToken` | automountServiceAccountToken controls whether the Kubernetes service account token is automatically mounted into the control plane pod. Set to false to disable automatic token mounting (e.g. for compliance environments). When disabled, use nginxGateway.extraVolumes to mount a projected token with a custom audience or expiration if required. | bool | `true` |
| `nginxGateway.serviceAccount.imagePullSecret` | The name of the secret containing docker registry credentials for the control plane. Secret must exist in the same namespace as the helm release. | string | `""` |
| `nginxGateway.serviceAccount.imagePullSecrets` | A list of secret names containing docker registry credentials for the control plane. Secrets must exist in the same namespace as the helm release. | list | `[]` |
| `nginxGateway.serviceAccount.name` | The name of the service account of the NGINX Gateway Fabric control plane pods. Used for RBAC. | string | Autogenerated if not set or set to "" |
| `nginxGateway.snippets.enable` | Enable Snippets feature through SnippetsFilter and SnippetsPolicy APIs. SnippetsFilters allow inserting NGINX configuration into the generated NGINX config for HTTPRoute and GRPCRoute resources. SnippetsPolicies allow inserting NGINX configuration into the generated NGINX config for Gateway resources. | bool | `false` |
| `nginxGateway.snippetsFilters.enable` | This flag is deprecated in favor of the snippets.enable flag. The latter will enable snippets for both SnippetsFilters and SnippetsPolicies. Enable SnippetsFilters feature. SnippetsFilters allow inserting NGINX configuration into the generated NGINX config for HTTPRoute and GRPCRoute resources. | bool | `false` |
| `nginxGateway.terminationGracePeriodSeconds` | The termination grace period of the NGINX Gateway Fabric control plane pod. | int | `30` |
| `nginxGateway.tolerations` | Tolerations for the NGINX Gateway Fabric control plane pod. | list | `[]` |
| `nginxGateway.topologySpreadConstraints` | The topology spread constraints for the NGINX Gateway Fabric control plane pod. | list | `[]` |
| `nginxGateway.watchNamespaces` | List of namespaces to watch for resources. If not set, all namespaces are watched. The controller's own namespace is always included. NOTE: If PLM is installed and configured via nginxGateway.plmStorage, ensure PLM's policyController.watchNamespace covers the namespaces where APPolicy and APLogConf resources will be created. | list | `[]` |
| `serverTLSDomain` | The domain suffix used in the server TLS certificate SAN and agent config host. Defaults to "svc". | string | `"svc"` |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs](https://github.com/norwoodj/helm-docs)
